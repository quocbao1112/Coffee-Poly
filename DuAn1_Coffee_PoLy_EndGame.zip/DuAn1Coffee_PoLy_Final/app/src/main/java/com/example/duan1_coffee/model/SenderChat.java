package com.example.duan1_coffee.model;

public class SenderChat {
    public DataChat data;
    public String to;

    public SenderChat(DataChat data, String to) {
        this.data = data;
        this.to = to;
    }


}

package com.example.duan1_coffee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class XacNhanPassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xac_nhan_pass);
    }
}

package com.example.duan1_coffee.model;

public class MyResponseChat {
    public int success;
}

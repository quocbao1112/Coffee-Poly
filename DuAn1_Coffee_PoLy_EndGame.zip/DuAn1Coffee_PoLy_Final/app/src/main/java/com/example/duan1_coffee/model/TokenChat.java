package com.example.duan1_coffee.model;

public class TokenChat {
    private String token;

    public TokenChat(String token){
        this.token=token;
    }

   public TokenChat(){

   }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

package com.example.duan1_coffee;

public class DocBao {
    public String title;
    public String link;
    public String image;

    public DocBao(String title, String link, String image) {
        this.title = title;
        this.link = link;
        this.image = image;
    }

}

